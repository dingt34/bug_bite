const store = require('../../utils/store');
const nav = require('../../utils/nav');
const cloud = require('../../utils/cloud');
const records = require('../../utils/event-records');

function decorate(event) {
  let icon = '/assets/figma/all/s13-img3.svg';
  if (event.contactType === 'sting' || event.type.indexOf('蜂') >= 0) icon = '/assets/figma/all/s13-img2.svg';
  if (event.contactType === 'unknown' || event.type.indexOf('不确定') >= 0) icon = '/assets/figma/all/s13-img1.svg';
  return Object.assign({}, event, {
    icon,
    levelClass: event.riskLevel === 'consult' ? 'level-consult' : event.riskLevel === 'emergency' ? 'level-emergency' : 'level-observe'
  });
}

Page({
  data: {
    events: [], allEvents: [], pendingEvents: [], historyEvents: [], tab: 'pending', query: '',
    riskFilter: 'all', filterLabel: '筛选', syncing: false, syncText: '所有记录已同步'
  },

  onShow() { this.loadEvents(); },

  loadEvents() {
    const now = Date.now();
    const events = store.get('events', []).map(item => records.normalizeEvent(item, now));
    store.set('events', events);
    this.setData({ events });
    this.applyFilters();
  },

  applyFilters() {
    const filtered = this.data.events.filter(item => {
      const riskMatches = this.data.riskFilter === 'all' || item.riskLevel === this.data.riskFilter;
      return riskMatches && records.matches(item, this.data.query);
    }).map(decorate);
    const pendingEvents = filtered.filter(item => item.status === '待复查');
    const historyEvents = filtered.filter(item => item.status !== '待复查');
    const pendingSync = this.data.events.some(item => item.syncStatus !== '已同步');
    this.setData({ allEvents: filtered, pendingEvents, historyEvents, syncText: pendingSync ? '有记录等待同步' : '所有记录已同步' });
  },

  back() { nav.back(); },
  setTab(e) { this.setData({ tab: e.currentTarget.dataset.tab }); },
  onSearch(e) { this.setData({ query: e.detail.value || '' }); this.applyFilters(); },

  chooseFilter() {
    const options = [
      { label: '全部风险等级', value: 'all' }, { label: '紧急求助', value: 'emergency' },
      { label: '尽快咨询', value: 'consult' }, { label: '观察记录', value: 'observe' }
    ];
    wx.showActionSheet({
      itemList: options.map(item => item.label),
      success: result => {
        const selected = options[result.tapIndex];
        this.setData({ riskFilter: selected.value, filterLabel: selected.value === 'all' ? '筛选' : selected.label });
        this.applyFilters();
      }
    });
  },

  open(e) { wx.navigateTo({ url: `/pages/event-detail/event-detail?id=${e.currentTarget.dataset.id}` }); },
  create() { wx.navigateTo({ url: '/pages/danger/danger?source=events' }); },

  syncAll() {
    if (this.data.syncing) return;
    if (!cloud.available()) {
      wx.showToast({ title: '当前离线，记录仍保存在本机', icon: 'none' });
      return;
    }
    this.setData({ syncing: true, syncText: '正在同步记录…' });
    Promise.all(this.data.events.map(event => cloud.call('userData', {
      action: 'upsert', type: 'event', clientId: event.id, record: records.toCloudRecord(event)
    }))).then(() => {
      const events = this.data.events.map(item => Object.assign({}, item, { syncStatus: '已同步' }));
      store.set('events', events);
      this.setData({ events, syncText: '所有记录已同步' });
      wx.showToast({ title: '同步完成', icon: 'success' });
      this.applyFilters();
    }).catch(() => {
      this.setData({ syncText: '同步失败，可稍后重试' });
      wx.showToast({ title: '同步失败，本机记录未丢失', icon: 'none' });
    }).then(() => this.setData({ syncing: false }));
  }
});
