const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [{
  id: 'event_1', type: '蚊虫叮咬', contactType: 'bite', riskLevel: 'observe',
  place: '公园草地', body: '右小腿', symptoms: ['红肿'], trend: '基本不变',
  createdAtTimestamp: Date.now() - 3600000, nextReviewAtTimestamp: Date.now() + 3600000,
  status: '待复查'
}];

let definition;
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  showModal() {},
  showActionSheet(options) { options.success({ tapIndex: 3 }); }
};

require('../miniprogram/pages/event-detail/event-detail.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onLoad({ id: 'event_1' });
page.onShow();
page.adjustReview();
assert.strictEqual(page.data.customReviewVisible, true);

const target = Date.now() + 24 * 60 * 60 * 1000;
page.onCustomDate({ detail: { value: page.dateValue(target) } });
page.onCustomTime({ detail: { value: page.timeValue(target) } });
page.confirmCustomReview();

assert.strictEqual(page.data.customReviewVisible, false);
assert.ok(storage[prefix + 'events'][0].nextReviewAtTimestamp > Date.now());
assert.strictEqual(storage[prefix + 'events'][0].status, '待复查');
console.log('event detail page tests passed');
