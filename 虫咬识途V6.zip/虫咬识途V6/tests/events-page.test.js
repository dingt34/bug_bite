const assert = require('assert');
const fs = require('fs');
const path = require('path');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [
  {
    id: 'pending_1', type: '蚊虫叮咬', riskLevel: 'observe', status: '待复查',
    place: '公园', body: '小腿', symptoms: ['红肿'], trend: '基本不变',
    createdAtTimestamp: Date.now() - 3600000, nextReviewAtTimestamp: Date.now() + 3600000
  },
  {
    id: 'history_1', type: '蜂类蜇伤', riskLevel: 'consult', status: '已恢复',
    place: '郊外', body: '手背', symptoms: [], trend: '明显减轻',
    createdAtTimestamp: Date.now() - 86400000, nextReviewAtTimestamp: 0
  }
];

let definition;
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; }
};

require('../miniprogram/pages/events/events.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onShow();
assert.strictEqual(page.data.tab, 'pending');
assert.deepStrictEqual(page.data.pendingEvents.map(item => item.id), ['pending_1']);
assert.deepStrictEqual(page.data.historyEvents.map(item => item.id), ['history_1']);
assert.deepStrictEqual(page.data.allEvents.map(item => item.id), ['pending_1', 'history_1']);

const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/events/events.wxml'), 'utf8');
assert.ok(wxml.includes("tab==='pending' && pendingEvents.length"));
assert.ok(wxml.includes("wx:if=\"{{tab==='all'}}\""));
assert.ok(wxml.includes('尽快复查'));
assert.ok(wxml.includes('class="tab-count"'));
const wxss = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/events/events.wxss'), 'utf8');
assert.ok(wxss.includes('.level-consult{background:#ffd84d;color:#111}'));
assert.ok(wxss.includes('.tab-count{width:42rpx;height:42rpx;border:2rpx solid #8c8f96'));
assert.ok(wxss.includes('.mode-tab.active .tab-count{border-color:#2f875f'));
console.log('events page tests passed');
