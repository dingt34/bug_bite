const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'plans'] = [{ id: 'plan_1', title: '丽水徒步', date: '9月5日', type: '徒步' }];
storage[prefix + 'events'] = [{
  id: 'event_1', type: '蚊虫叮咬', riskLevel: 'observe', place: '公园草地', body: '右小腿',
  symptoms: ['红肿'], trend: '基本不变', createdAtTimestamp: Date.now() - 3600000, status: '待复查'
}];

let definition;
let cloudPayload;
let modalTitle = '';
global.Page = value => { definition = value; };
global.getApp = () => ({ globalData: { cloudReady: true } });
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  showModal(options) { modalTitle = options.title; },
  navigateTo() {},
  cloud: {
    callFunction(options) {
      cloudPayload = options.data;
      return Promise.resolve({ result: { ok: true, data: { answer: '请继续观察记录。' } } });
    }
  }
};

require('../miniprogram/pages/ai/ai.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); },
  getTabBar() { return null; }
});

(async () => {
  assert.strictEqual(page.data.messages.length, 0);
  page.onShow();
  page.toggleRecord({ currentTarget: { dataset: { key: 'event:event_1' } } });
  page.confirmRecords();
  page.setData({ input: '这条记录接下来注意什么？' });
  page.send();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.deepStrictEqual(cloudPayload.selectedRecordIds, ['event:event_1']);
  const lastContent = cloudPayload.messages[cloudPayload.messages.length - 1].content;
  assert.ok(lastContent.indexOf('蚊虫叮咬') >= 0);
  assert.ok(lastContent.indexOf('丽水徒步') < 0);

  cloudPayload = null;
  page.setData({ input: '' });
  page.send();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.ok(cloudPayload);
  const recordOnlyContent = cloudPayload.messages[cloudPayload.messages.length - 1].content;
  assert.ok(recordOnlyContent.indexOf('请根据我选择的记录') >= 0);
  assert.ok(recordOnlyContent.indexOf('蚊虫叮咬') >= 0);
  const latestUser = page.data.messages.filter(item => item.role === 'user').pop();
  assert.ok(latestUser.attachmentLabel.indexOf('蚊虫叮咬') >= 0);
  assert.ok(page.data.scrollIntoView.indexOf('chat-bottom-') === 0);

  page.clearRecords();
  page.saveLastAnswer();
  assert.strictEqual(storage[prefix + 'events'][0].notes.length, 1);
  assert.deepStrictEqual(storage[prefix + 'events'][0].notes[0].selectedRecordIds, ['event:event_1']);

  const eventOption = page.data.selectableRecords.find(item => item.key === 'event:event_1');
  eventOption.summary += '，并出现呼吸困难';
  page.toggleRecord({ currentTarget: { dataset: { key: 'event:event_1' } } });
  page.confirmRecords();
  cloudPayload = null;
  page.setData({ input: '' });
  page.send();
  assert.strictEqual(modalTitle, '先进行安全判断');
  assert.strictEqual(cloudPayload, null);

  page.clearRecords();
  cloudPayload = null;
  page.setData({ input: '现在呼吸困难而且快速加重' });
  page.send();
  assert.strictEqual(modalTitle, '先进行安全判断');
  assert.strictEqual(cloudPayload, null);
  const wxml = require('fs').readFileSync(require('path').join(__dirname, '../miniprogram/pages/ai/ai.wxml'), 'utf8');
  const wxss = require('fs').readFileSync(require('path').join(__dirname, '../miniprogram/pages/ai/ai.wxss'), 'utf8');
  assert.ok(wxml.includes('class="ai-controls"'));
  assert.ok(wxml.includes('chat-bottom-{{scrollToken}}'));
  assert.ok(wxss.includes('.record-picker{position:relative'));
  assert.ok(wxss.includes('.page.with-tab.ai-page'));
  const cloudCode = require('fs').readFileSync(require('path').join(__dirname, '../cloudfunctions/aiAssistant/index.js'), 'utf8');
  assert.ok(cloudCode.includes("console.error('ai audit skipped'"));
  console.log('ai page tests passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
