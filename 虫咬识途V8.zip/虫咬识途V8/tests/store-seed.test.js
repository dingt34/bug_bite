const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'plans'] = [];
storage[prefix + 'posts'] = [];
storage[prefix + 'events'] = [
  { id: 'event_mosquito', type: '蚊虫叮咬' },
  { id: 'event_bee', type: '蜂类蜇伤' },
  { id: 'event_real_1', type: '蚊虫叮咬' }
];

global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; }
};

const store = require('../miniprogram/utils/store');
store.seed();
assert.deepStrictEqual(storage[prefix + 'events'].map(item => item.id), ['event_real_1']);

delete storage[prefix + 'events'];
store.seed();
assert.deepStrictEqual(storage[prefix + 'events'], []);

console.log('store seed tests passed');
