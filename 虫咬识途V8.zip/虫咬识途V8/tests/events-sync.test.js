const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [
  { id: 'ok_1', type: '蚊虫叮咬', riskLevel: 'observe', status: '待复查', place: '公园', body: '小腿', symptoms: ['红肿'], trend: '基本不变', createdAtTimestamp: Date.now() - 3600000, syncStatus: '待同步' },
  { id: 'fail_1', type: '蜂类蜇伤', riskLevel: 'consult', status: '待复查', place: '郊外', body: '手背', symptoms: ['疼痛'], trend: '基本不变', createdAtTimestamp: Date.now() - 7200000, syncStatus: '待同步' }
];

let definition;
let retryMode = false;
const calls = [];
global.Page = value => { definition = value; };
global.getApp = () => ({ globalData: { cloudReady: true } });
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  cloud: {
    callFunction(options) {
      calls.push(options.data.clientId);
      if (options.data.clientId === 'fail_1' && !retryMode) {
        return Promise.resolve({ result: { ok: false, code: 'FUNCTION_NOT_FOUND', message: 'function not found' } });
      }
      return Promise.resolve({ result: { ok: true, data: { clientId: options.data.clientId } } });
    }
  }
};

require('../miniprogram/pages/events/events.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

(async () => {
  page.onShow();
  page.syncAll();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.strictEqual(page.data.syncState, 'error');
  assert.ok(page.data.syncText.indexOf('已同步 1 条，失败 1 条') >= 0);
  assert.strictEqual(page.data.syncDetail, '请稍后再次重试');
  assert.ok(storage[prefix + 'events'].find(item => item.id === 'fail_1').syncError.indexOf('userData 云函数尚未部署') >= 0);
  assert.strictEqual(storage[prefix + 'events'].find(item => item.id === 'ok_1').syncStatus, '已同步');
  assert.strictEqual(storage[prefix + 'events'].find(item => item.id === 'fail_1').syncStatus, '待同步');

  retryMode = true;
  const callCount = calls.length;
  page.syncAll();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.deepStrictEqual(calls.slice(callCount), ['fail_1']);
  assert.strictEqual(page.data.syncState, 'success');
  assert.ok(storage[prefix + 'events'].every(item => item.syncStatus === '已同步'));
  console.log('events sync tests passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
