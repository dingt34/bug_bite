const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  navigateTo() {},
  showToast() {}
};

function loadPage(relativePath) {
  let definition;
  global.Page = value => { definition = value; };
  const resolved = require.resolve(relativePath);
  delete require.cache[resolved];
  require(relativePath);
  return Object.assign({}, definition, {
    data: JSON.parse(JSON.stringify(definition.data)),
    setData(update) { this.data = Object.assign({}, this.data, update); }
  });
}

const labels = {
  bite: '蚊虫叮咬',
  sting: '蜂类蜇伤',
  attachment: '发现附着虫体',
  contact: '接触后皮疹/不适',
  unknown: '不确定接触'
};

Object.keys(labels).forEach(contactType => {
  storage[prefix + 'events'] = [];
  storage[prefix + 'safetyDraft'] = { place: '测试地点', body: '手臂' };

  const contact = loadPage('../miniprogram/pages/contact/contact.js');
  contact.onLoad();
  contact.select({ currentTarget: { dataset: { id: contactType } } });
  contact.next();
  assert.strictEqual(storage[prefix + 'safetyDraft'].contactType, contactType);
  assert.strictEqual(storage[prefix + 'safetyDraft'].place, '测试地点');

  const guide = loadPage('../miniprogram/pages/guide/guide.js');
  guide.onLoad({ type: contactType });
  guide.next();
  assert.strictEqual(storage[prefix + 'safetyDraft'].contactType, contactType);
  assert.strictEqual(storage[prefix + 'safetyDraft'].body, '手臂');

  const result = loadPage('../miniprogram/pages/result/result.js');
  result.onLoad({ level: 'observe' });
  const saved = storage[prefix + 'events'][0];
  assert.strictEqual(saved.contactType, contactType);
  assert.strictEqual(saved.type, labels[contactType]);
});

console.log('safety flow tests passed');
