const assert = require('assert');
const fs = require('fs');
const path = require('path');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [{
  id: 'event_1', type: '蚊虫叮咬', contactType: 'bite', riskLevel: 'observe',
  place: '公园草地', body: '右小腿', symptoms: ['红肿'], trend: '基本不变',
  createdAtTimestamp: Date.now() - 3600000, nextReviewAtTimestamp: Date.now() + 3600000,
  status: '待复查'
}];

let definition;
let modalTitle = '';
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  showModal(options) { modalTitle = options.title; },
  showActionSheet(options) { options.success({ tapIndex: 3 }); }
};

require('../miniprogram/pages/event-detail/event-detail.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onLoad({ id: 'event_1' });
page.onShow();
page.adjustReview();
assert.strictEqual(page.data.customReviewVisible, true);

const target = Date.now() + 24 * 60 * 60 * 1000;
page.onCustomDate({ detail: { value: page.dateValue(target) } });
page.onCustomTime({ detail: { value: page.timeValue(target) } });
page.confirmCustomReview();

assert.strictEqual(page.data.customReviewVisible, false);
assert.ok(storage[prefix + 'events'][0].nextReviewAtTimestamp > Date.now());
assert.strictEqual(storage[prefix + 'events'][0].status, '待复查');
assert.ok(page.data.timeline[0].symptomsText.indexOf('红肿') >= 0);
const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/event-detail/event-detail.wxml'), 'utf8');
const wxss = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/event-detail/event-detail.wxss'), 'utf8');
assert.ok(wxml.includes('如已开启订阅将按时提醒'));
assert.ok(wxml.includes('历史最高'));
assert.ok(wxml.includes('<view class="timeline-detail">'));
assert.ok(wxss.includes('.adjust{align-self:flex-end;padding:14rpx 20rpx;border:2rpx solid #2f875f'));
assert.ok(wxss.includes('.ai-entry{margin-top:24rpx;padding:18rpx;color:#1e2021'));
assert.ok(wxml.includes('wx:if="{{isPending}}"'));
assert.ok(wxml.includes('重新开启观察'));

const missingPage = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});
missingPage.onLoad({ id: 'missing_event' });
missingPage.onShow();
assert.strictEqual(modalTitle, '记录不存在');
assert.strictEqual(missingPage.data.event.id, undefined);
console.log('event detail page tests passed');
