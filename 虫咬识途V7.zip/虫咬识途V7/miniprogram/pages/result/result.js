const store=require('../../utils/store'); const nav=require('../../utils/nav'); const eventRecords=require('../../utils/event-records');
const copy={emergency:{title:'紧急求助',sub:'已发现危险信号',color:'#EA4038'},consult:{title:'尽快咨询',sub:'症状正在加重',color:'#EA8B18'},observe:{title:'观察记录',sub:'当前未发现高危信号',color:'#E99A1A'}};
Page({
  data:{level:'observe',info:copy.observe,eventId:''},
  onLoad(q){const level=q.level||'observe';this.setData({level,info:copy[level]});this.saveEvent(level);}, back(){nav.back();},
  saveEvent(level){const draft=store.get('safetyDraft',{});const events=store.get('events',[]);const event=eventRecords.createEvent({id:store.id('event'),contactType:draft.contactType||'unknown',riskLevel:level,place:draft.place||'待补充',body:draft.body||'待补充',symptoms:draft.symptoms||[],trend:draft.trend||'待观察',measures:draft.measures||[],imageRefs:draft.imageRefs||[]});events.unshift(event);store.set('events',events);this.setData({eventId:event.id});},
  call(){wx.makePhoneCall({phoneNumber:'120'});}, home(){wx.switchTab({url:'/pages/home/home'});}, events(){wx.navigateTo({url:'/pages/events/events'});}
});
