const assert = require('assert');

const storage = {};
const prefix = 'bugtrail_v4_';
const createdAt = Date.now() - 2 * 60 * 60 * 1000;
storage[prefix + 'events'] = [{
  id: 'event_1', type: '蚊虫叮咬', contactType: 'bite', riskLevel: 'observe', level: '观察记录',
  place: '公园草地', body: '右小腿', symptoms: ['红肿'], trend: '基本不变',
  createdAtTimestamp: createdAt, nextReviewAtTimestamp: Date.now(), status: '待复查'
}];

let definition;
let navigatedBack = false;
global.Page = value => { definition = value; };
global.getCurrentPages = () => [{}, {}];
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  navigateBack() { navigatedBack = true; },
  navigateTo() {}
};

require('../miniprogram/pages/review/review.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onLoad({ id: 'event_1' });
page.setTrend({ currentTarget: { dataset: { value: '逐渐加重' } } });
page.setRange({ currentTarget: { dataset: { value: '扩大' } } });
page.toggleSymptom({ currentTarget: { dataset: { value: '其他' } } });
page.onCustomSymptomInput({ detail: { value: '皮肤触感比之前更硬' } });
page.toggleMeasure({ currentTarget: { dataset: { value: '冷敷' } } });
page.save();

setTimeout(() => {
  const updated = storage[prefix + 'events'][0];
  assert.strictEqual(updated.timeline.length, 2);
  assert.strictEqual(updated.timeline[0].recordedAtTimestamp, createdAt);
  assert.strictEqual(updated.timeline[1].kind, 'review');
  assert.strictEqual(updated.riskLevel, 'consult');
  assert.deepStrictEqual(updated.measures, ['冷敷']);
  assert.ok(updated.symptoms.includes('皮肤触感比之前更硬'));
  assert.ok(!updated.symptoms.includes('其他'));
  assert.strictEqual(navigatedBack, true);
  console.log('review page tests passed');
}, 550);
