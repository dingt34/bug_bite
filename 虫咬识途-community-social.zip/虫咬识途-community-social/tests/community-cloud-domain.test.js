const assert = require('assert');
const domain = require('../cloudfunctions/community/domain.js');

const post = domain.normalizePost({
  text: '记录一次林地活动后的叮咬经历',
  region: '丽水',
  contactType: 'bite',
  contactTypeName: '叮咬',
  stage: '观察中',
  imageRefs: ['cloud://env/community.jpg', 'wxfile://local.jpg']
});
assert.deepStrictEqual(post.tags, ['丽水', '叮咬', '观察中']);
assert.deepStrictEqual(post.imageRefs, ['cloud://env/community.jpg']);
assert.throws(() => domain.normalizePost({ text: '太短' }), /至少填写5个字/);
assert.throws(() => domain.normalizePost({ text: '这是一段完整经历', contactType: 'invalid', stage: '观察中' }), /有效/);
assert.throws(() => domain.normalizePost({ text: '这是一段完整经历', contactType: 'bite', stage: '未知阶段' }), /有效/);
assert.throws(() => domain.normalizeComment('一'), /至少需要2个字/);
assert.strictEqual(domain.normalizeMessage('  你好，想交流一下防护经验  '), '你好，想交流一下防护经验');
assert.throws(() => domain.normalizeMessage('   '), /请输入私信内容/);
assert.strictEqual(domain.normalizeReportReason('医疗误导'), '医疗误导');
assert.strictEqual(domain.normalizeReportReason('用户标记不当内容'), '其他');
assert.throws(() => domain.normalizeReportReason('随意原因'), /有效的举报原因/);
const scoreNow = 10 * 24 * 60 * 60 * 1000;
assert.ok(
  domain.hotScore({ likeCount: 5, createdAtTimestamp: scoreNow }, scoreNow) >
  domain.hotScore({ likeCount: 5, createdAtTimestamp: scoreNow - 7 * 24 * 60 * 60 * 1000 }, scoreNow)
);
assert.strictEqual(
  domain.stableId('reaction', 'openid', 'post'),
  domain.stableId('reaction', 'openid', 'post')
);
assert.strictEqual(domain.matchesQuery({ text: '丽水徒步', tags: [] }, '丽水'), true);
assert.strictEqual(domain.conversationId('user-a', 'user-b'), domain.conversationId('user-b', 'user-a'));
assert.strictEqual(domain.publicUserId('openid-a'), domain.publicUserId('openid-a'));
assert.notStrictEqual(domain.publicUserId('openid-a'), 'openid-a');

const publicUser = domain.publicUser({ displayName: '林间旅人' }, 'openid-a', { unreadCount: 2 });
assert.strictEqual(publicUser.displayName, '林间旅人');
assert.strictEqual(publicUser.avatarText, '林');
assert.strictEqual(publicUser.unreadCount, 2);
assert.strictEqual(publicUser.openid, undefined);

const publicMessage = domain.publicMessage({
  _id: 'm1', senderOpenid: 'openid-a', recipientOpenid: 'openid-b', kind: 'post',
  postId: 'p1', postPreview: { text: '户外经历' }, createdAtTimestamp: 200, readAtTimestamp: 0
}, 'openid-a');
assert.strictEqual(publicMessage.mine, true);
assert.strictEqual(publicMessage.kind, 'post');
assert.strictEqual(publicMessage.senderOpenid, undefined);

const publicValue = domain.publicPost({
  _id: 'p1', authorOpenid: 'u1', displayName: '作者', text: '内容', likeCount: 2
}, { liked: true }, 'u1');
assert.strictEqual(publicValue.canDelete, true);
assert.strictEqual(publicValue.liked, true);
assert.strictEqual(publicValue.contactTypeName, '');
assert.strictEqual(publicValue.shareCount, 0);
assert.ok(publicValue.authorId);
assert.strictEqual(publicValue.authorOpenid, undefined);
assert.deepStrictEqual(domain.transactionValue({ result: { success: true }, errMsg: 'ok' }), { success: true });

console.log('community cloud domain tests passed');
