const assert = require('assert');
const cloudService = require('../miniprogram/utils/cloud-service.js');

let pageDefinition = null;
let navigatedBack = false;
let publishCalls = 0;
let updateCalls = 0;
let uploadedPath = '';
const storage = {};
const userInfo = {
  id: 'cloud_user', displayName: '山野观察员', avatarText: '山', mode: 'wechat_cloud'
};

global.Page = definition => { pageDefinition = definition; };
global.wx = {
  getStorageSync(key) {
    if (key === 'userInfo') return userInfo;
    return storage[key] || null;
  },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  chooseImage() {},
  showToast() {},
  showModal(options) { if (options.success) options.success({ confirm: true }); },
  setNavigationBarTitle() {},
  navigateBack() { navigatedBack = true; },
  cloud: {
    init() {},
    uploadFile(options) {
      uploadedPath = options.filePath;
      return Promise.resolve({ fileID: 'cloud://env/community.jpg' });
    },
    deleteFile() { return Promise.resolve({ fileList: [] }); },
    callFunction(options) {
      if (options.data.action === 'publish') {
        publishCalls += 1;
        assert.strictEqual(options.data.profile.displayName, '山野观察员');
        assert.deepStrictEqual(options.data.post.imageRefs, ['cloud://env/community.jpg']);
        return Promise.resolve({ result: { post: { id: 'cloud_post_1' } } });
      }
      if (options.data.action === 'get') {
        return Promise.resolve({ result: {
          post: {
            id: 'cloud_post_1', displayName: '山野观察员', text: '原有林地经历',
            imageRefs: ['cloud://env/original.jpg'], region: '丽水', contactType: 'bite',
            contactTypeName: '叮咬', stage: '观察中', tags: ['丽水', '叮咬', '观察中'],
            createdAtTimestamp: Date.now() - 1000, updatedAtTimestamp: Date.now() - 1000,
            canDelete: true
          },
          comments: [], reported: false
        } });
      }
      if (options.data.action === 'updatePost') {
        updateCalls += 1;
        assert.strictEqual(options.data.postId, 'cloud_post_1');
        assert.strictEqual(options.data.post.text, '修改后的林地经历内容');
        return Promise.resolve({ result: { post: { id: 'cloud_post_1' } } });
      }
      if (options.data.action === 'stats') return Promise.resolve({ result: { posts: 1, comments: 0, collections: 0 } });
      return Promise.resolve({ result: {} });
    }
  }
};

cloudService.resetForTests();
require('../miniprogram/pages/post-publish/post-publish.js');

function createPage() {
  return Object.assign({}, pageDefinition, {
    data: Object.assign({}, pageDefinition.data),
    setData(update) { this.data = Object.assign({}, this.data, update); }
  });
}

(async () => {
  const page = createPage();
  page.publish();
  assert.ok(page.data.validationMessage.includes('经历内容'));

  page.setData({
    text: '记录一次林地活动后的叮咬经历',
    previewImage: '/tmp/community.jpg',
    contactType: 'bite',
    contactTypeName: '叮咬',
    stage: '观察中',
    region: '丽水'
  });
  page.publish();
  await new Promise(resolve => setTimeout(resolve, 450));
  assert.strictEqual(publishCalls, 1);
  assert.strictEqual(uploadedPath, '/tmp/community.jpg');
  assert.strictEqual(navigatedBack, true);
  page.publish();
  assert.strictEqual(publishCalls, 1);

  storage.communityPostDraftV1 = {
    text: '自动保存的社群草稿内容', region: '杭州',
    contactType: 'bite', contactTypeName: '叮咬', stage: '观察中'
  };
  const draftPage = createPage();
  draftPage.onLoad({});
  assert.strictEqual(draftPage.data.draftRestored, true);
  assert.strictEqual(draftPage.data.text, '自动保存的社群草稿内容');
  draftPage.onInput({ detail: { value: '更新后的草稿内容' } });
  assert.strictEqual(storage.communityPostDraftV1.text, '更新后的草稿内容');

  const editPage = createPage();
  editPage.onLoad({ id: 'cloud_post_1' });
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.strictEqual(editPage.data.editing, true);
  assert.strictEqual(editPage.data.previewImage, 'cloud://env/original.jpg');
  editPage.setData({ text: '修改后的林地经历内容' });
  editPage.publish();
  await new Promise(resolve => setTimeout(resolve, 450));
  assert.strictEqual(updateCalls, 1);
  cloudService.resetForTests();
  console.log('post publish page tests passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
