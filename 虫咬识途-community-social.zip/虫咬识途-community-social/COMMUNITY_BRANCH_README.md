# 社群功能分支说明

建议分支名：`feature/community-social`

## 本分支范围

- 社群帖子浏览、搜索、主题筛选、最新/热门排序、下拉刷新和触底加载。
- 帖子发布、图片上传、草稿自动保存与恢复、草稿清空。
- 作者编辑、删除自己的帖子，以及更换或移除帖子图片。
- 点赞、收藏、评论、删除自己的评论。
- 举报原因选择、服务端原因校验和举报者侧隐藏。
- 热门排序加入时间衰减，减少旧帖子长期占据前排。
- 服务端校验接触类型和当前阶段，避免客户端伪造无效标签。
- 从帖子作者卡片发起好友申请，支持申请接受、忽略与双向申请自动接受。
- 好友列表、未读私信提示、好友一对一私信和会话已读状态。
- 帖子站内转发到好友私信，并保留微信原生分享入口与转发计数。
- 原始微信 `OPENID` 仅在云函数内部使用，客户端使用不可逆公开用户标识。

## 主要修改位置

- `miniprogram/pages/community/`
- `miniprogram/pages/post-publish/`
- `miniprogram/pages/post-detail/`
- `miniprogram/pages/friends/`
- `miniprogram/pages/friend-chat/`
- `miniprogram/utils/community.js`
- `miniprogram/utils/community-cloud.js`
- `miniprogram/utils/community-social.js`
- `cloudfunctions/community/`
- `tests/community*.test.js`
- `tests/post-*.test.js`

## 云端部署

本分支沿用现有 `community` 云函数和以下集合：

- `community_posts`
- `community_comments`
- `community_reactions`
- `community_reports`
- `community_friendships`
- `community_messages`

合并代码后需要重新上传并部署 `cloudfunctions/community`，并创建两个新增集合及索引，否则好友、私信和站内转发不会生效。

## Pull Request 摘要

### 修改内容

- 完善社群浏览、发布和互动流程。
- 增加发帖草稿、帖子编辑、图片移除/替换和举报原因选择。
- 加强云函数字段校验，并优化热门内容排序。
- 增加好友申请、好友列表、一对一私信、未读提示和帖子站内转发。
- 增加对应自动测试。

### 测试方式

- 运行 `tests/community*.test.js`、`tests/friends-page.test.js`、`tests/friend-chat-page.test.js`、`tests/post-publish-page.test.js` 和 `tests/post-detail-page.test.js`。
- 在微信开发者工具中验证发布草稿、编辑帖子、评论、收藏和举报流程。
- 部署 `community` 云函数后，使用两个微信账号验证好友申请、接受/忽略、双向私信、未读状态、站内转发、作者权限与公共帖子可见性。
