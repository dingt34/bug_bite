# 微信云开发部署说明

代码已经包含微信云登录、云数据库同步和云存储图片上传。首次运行真实云功能前，需要在微信开发者工具中完成以下配置。

## 1. 开通云开发环境

1. 使用本项目 AppID 打开微信开发者工具。
2. 点击“云开发”，创建测试或正式环境。
3. 复制环境 ID，填写到 `miniprogram/config/cloud.js` 的 `ENV_ID`。

## 2. 创建数据库集合

在云开发控制台创建以下集合：

- `users`：保存微信云身份的昵称、头像云文件 ID 和登录时间。
- `user_data`：保存每个微信用户的计划、事件和个人图片映射同步快照。
- `community_posts`：保存所有用户可见的公共帖子和互动计数。
- `community_comments`：保存公共评论。
- `community_reactions`：保存用户对帖子的点赞和收藏状态。
- `community_reports`：保存社区内容举报记录。
- `community_friendships`：保存好友申请及已接受的好友关系。
- `community_messages`：保存好友私信和站内转发的帖子卡片。

以上集合都应设置为“不允许小程序客户端直接读写”或等价的管理员/云函数专用权限。所有身份确认与数据库操作均通过云函数完成。

## 3. 部署云函数

在开发者工具中依次右键以下目录，选择“上传并部署：云端安装依赖”：

- `cloudfunctions/login`
- `cloudfunctions/syncData`
- `cloudfunctions/community`

部署环境必须与 `ENV_ID` 指向的环境一致。

## 4. 验证

1. 重新编译小程序，进入“我的 → 登录”。
2. 页面应显示“微信云开发已连接”。
3. 选择头像、填写昵称，点击“微信云登录”。
4. 创建计划或事件后进入“我的”，点击“立即同步”。
5. 发布一条社区内容，验证草稿恢复、帖子编辑、评论、点赞、收藏和选择原因举报。
6. 使用两个微信账号，从帖子详情发起好友申请；另一个账号接受后，验证双向私信、未读数和帖子转发。
7. 在云开发控制台检查 `users`、`user_data`、六个 `community_*` 集合，以及云存储的 `avatars/`、`user-content/`、`community/` 目录。

## 社区数据库索引

社区云函数部署后，按控制台提示为常用查询建立以下索引：

- `community_posts`：`status + createdAtTimestamp`，`authorOpenid + status`。
- `community_comments`：`postId + status + createdAtTimestamp`，`authorOpenid + status`。
- `community_reactions`：`authorOpenid`，`postId`。
- `community_reports`：`reporterOpenid`，`postId`。
- `community_friendships`：`requesterOpenid + status`，`recipientOpenid + status`。
- `community_messages`：`conversationId + createdAtTimestamp`，`recipientOpenid + readAtTimestamp`，`senderOpenid`。

六个社区集合均应设置为“不允许小程序客户端直接读写”。列表、发布、评论、好友关系、私信、转发、删除、举报和统计全部通过 `community` 云函数完成。

## 数据策略

- 核心业务始终先写本机，云同步失败不会阻断记录。
- 微信云身份由云函数 `getWXContext()` 提供的可信 `OPENID` 区分，客户端不会提交或指定其他用户的 `openid`。
- 本地图片同步前会上传至云存储，数据库只保存云文件 ID。
- 删除计划或离线安全卡时会同步删除标记，避免其他设备恢复已经删除的数据。
- 用户更换头像后，登录云函数会尝试清理上一张云端头像。
- 公共帖子、评论和互动不再写入个人 `user_data` 快照，避免不同用户之间的数据隔离问题。
- 好友与私信只使用云函数从可信 `OPENID` 建立关系；客户端仅接收不可逆的公开用户标识，不返回原始 `OPENID`。
- 只有已互相成为好友的用户可以读取会话、发送私信或站内转发帖子；打开会话后由云函数更新未读状态。
- 旧版本保存在本机的个人帖子会在完成微信云登录后尝试迁移一次到公共社区。
- “隐私与本机数据”页面可分别清除本机数据，或删除个人云备份和本人产生的社区数据。

## AI 建议助手

1. 微信开发者工具基础库选择 `3.7.1` 或更高版本。
2. 在云开发控制台开通 AI+ 服务并确认当前环境具有模型调用额度。
3. 文字聊天默认使用云开发内置 `hy3` 模型，无需填写 Agent ID。
4. 如需发送虫体或伤口图片，请在云开发控制台进入“AI → Agent”创建并启用一个安全建议 Agent。
5. 将 Agent ID 填入 `miniprogram/config/cloud.js` 的 `AI_BOT_ID`。
6. Agent 应明确设置为：不做虫种或疾病确诊，优先识别危险信号，严重情况建议立即呼叫 120 或就近急诊。

聊天页发送的手动图片会临时上传云存储，并在本轮回复结束后尝试删除；发送个人记录时由用户勾选计划或事件，只发送所选记录及复查的文字摘要，不发送未选记录，也不自动发送历史图片。
