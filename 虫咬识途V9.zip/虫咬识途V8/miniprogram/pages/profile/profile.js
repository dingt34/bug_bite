const store = require('../../utils/store');
const nav = require('../../utils/nav');

Page({
  data: {
    user: {}, event: {}, plan: {}, eventCount: 0, pendingEventCount: 0, eventSummary: '暂无记录', planCount: 0, planSummary: '暂无计划'
  },

  onShow() {
    nav.syncTab(this, 4);
    const storedEvents = store.get('events', []);
    const events = store.withoutDemoEvents(storedEvents);
    if (events.length !== storedEvents.length) store.set('events', events);
    const pendingEvents = events.filter(item => item.status === '待复查');
    const eventCount = events.length;
    const pendingEventCount = pendingEvents.length;
    const storedPlans = store.get('plans', []);
    const plans = store.withoutDemoPlans(storedPlans);
    if (plans.length !== storedPlans.length) store.set('plans', plans);
    this.setData({
      user: store.get('user', { nickname: '林间观察员', region: '浙江省 · 杭州市' }),
      event: pendingEvents[0] || events[0] || {},
      plan: plans[0] || {},
      eventCount,
      pendingEventCount,
      eventSummary: eventCount ? `${eventCount} 条记录 · ${pendingEventCount} 条待复查` : '暂无记录',
      planCount: plans.length,
      planSummary: plans.length ? `${plans.length} 个计划` : '暂无计划'
    });
  },

  edit() { wx.navigateTo({ url: '/pages/profile-edit/profile-edit' }); },
  events() { wx.navigateTo({ url: '/pages/events/events' }); },
  plans() { wx.navigateTo({ url: '/pages/my-plans/my-plans' }); },
  privacy() { wx.navigateTo({ url: '/pages/privacy/privacy' }); }
});
