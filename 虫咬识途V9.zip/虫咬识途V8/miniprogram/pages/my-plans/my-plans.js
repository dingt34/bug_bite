const store = require('../../utils/store');
const nav = require('../../utils/nav');

Page({
  data: { plans: [], mainPlan: {}, otherPlans: [], tabs: ['近期', '历史', '草稿'], tab: '近期' },
  onShow() {
    const storedPlans = store.get('plans', []);
    const plans = store.withoutDemoPlans(storedPlans);
    if (plans.length !== storedPlans.length) store.set('plans', plans);
    this.setData({ plans, mainPlan: plans[0] || {}, otherPlans: plans.slice(1) });
  },
  back() { nav.back(); },
  setTab(e) { this.setData({ tab: e.currentTarget.dataset.tab }); },
  open() { wx.navigateTo({ url: '/pages/precheck-result/precheck-result' }); },
  create() { wx.navigateTo({ url: '/pages/precheck/precheck' }); }
});
