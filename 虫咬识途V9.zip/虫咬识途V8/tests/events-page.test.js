const assert = require('assert');
const fs = require('fs');
const path = require('path');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [
  {
    id: 'event_mosquito', type: '蚊虫叮咬', riskLevel: 'observe', status: '待复查',
    place: '演示地点', body: '右小腿', symptoms: ['红肿'], trend: '基本不变',
    createdAtTimestamp: Date.now() - 3600000, nextReviewAtTimestamp: Date.now() + 3600000
  },
  {
    id: 'pending_1', type: '蚊虫叮咬', riskLevel: 'observe', status: '待复查',
    place: '待补充', body: '小腿', symptoms: ['红肿'], trend: '基本不变',
    createdAtTimestamp: Date.now() - 3600000, nextReviewAtTimestamp: Date.now() + 3600000
  },
  {
    id: 'history_1', type: '蜂类蜇伤', riskLevel: 'consult', status: '已恢复',
    place: '郊外', body: '手背', symptoms: [], trend: '明显减轻',
    createdAtTimestamp: Date.now() - 86400000, nextReviewAtTimestamp: 0
  },
  {
    id: 'attachment_1', type: '发现附着虫体', contactType: 'attachment', riskLevel: 'observe', status: '已恢复',
    place: '林地', body: '小腿', symptoms: [], trend: '明显减轻',
    createdAtTimestamp: Date.now() - 172800000, nextReviewAtTimestamp: 0
  },
  {
    id: 'contact_1', type: '接触后皮疹/不适', contactType: 'contact', riskLevel: 'observe', status: '已恢复',
    place: '草地', body: '手臂', symptoms: [], trend: '明显减轻',
    createdAtTimestamp: Date.now() - 259200000, nextReviewAtTimestamp: 0
  }
];

let definition;
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {}
};

require('../miniprogram/pages/events/events.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onShow();
assert.strictEqual(page.data.tab, 'pending');
assert.strictEqual(page.data.syncState, 'idle');
assert.deepStrictEqual(page.data.pendingEvents.map(item => item.id), ['pending_1']);
assert.deepStrictEqual(page.data.historyEvents.map(item => item.id), ['history_1', 'attachment_1', 'contact_1']);
assert.deepStrictEqual(page.data.allEvents.map(item => item.id), ['pending_1', 'history_1', 'attachment_1', 'contact_1']);
assert.strictEqual(page.data.allEvents.find(item => item.id === 'attachment_1').icon, '/assets/figma/s05-imgIconGeneratedIllustrated2.svg');
assert.strictEqual(page.data.allEvents.find(item => item.id === 'contact_1').icon, '/assets/figma/s05-imgIconGeneratedIllustrated3.svg');
assert.ok(!storage[prefix + 'events'].some(item => item.id === 'event_mosquito'));
page.syncAll();
assert.strictEqual(page.data.syncState, 'error');
assert.ok(page.data.syncText.indexOf('同步失败') >= 0);
assert.strictEqual(page.data.syncDetail, '请稍后再次重试');

const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/events/events.wxml'), 'utf8');
assert.ok(wxml.includes("tab==='pending' && pendingEvents.length"));
assert.ok(wxml.includes("wx:if=\"{{tab==='all'}}\""));
assert.ok(wxml.includes('reviewStateText'));
assert.ok(page.data.pendingEvents[0].reviewStateText === '待复查');
assert.strictEqual(page.data.pendingEvents[0].place, '');
assert.ok(!page.data.pendingEvents[0].eventMeta.includes('待补充'));
assert.ok(wxml.includes('class="tab-count"'));
assert.ok(wxml.includes('/assets/sync-error.svg'));
assert.ok(wxml.includes('/assets/sync-pending.svg'));
assert.ok(wxml.includes("syncState==='success'"));
assert.strictEqual((wxml.match(/class="circle circle-amber event-icon"/g) || []).length, 2);
assert.ok(!wxml.includes('class="circle history-icon"'));
const wxss = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/events/events.wxss'), 'utf8');
assert.ok(wxss.includes('.level-consult{background:#ffd84d;color:#111}'));
assert.ok(wxss.includes('.level-pill{width:168rpx;height:58rpx'));
assert.ok(wxss.includes('.level-consult{background:#ffd84d;color:#111;border-color:#e1b900;font-weight:700}'));
assert.ok(wxss.includes('.event-main{margin-right:16rpx}'));
assert.ok(wxss.includes('.tab-count{width:42rpx;height:42rpx;border:2rpx solid #8c8f96'));
assert.ok(wxss.includes('.mode-tab.active .tab-count{border-color:#2f875f'));
assert.ok(wxss.includes('.mode-tab{height:76rpx;display:flex;align-items:center;justify-content:center;border-radius:38rpx;color:#7f8582;font-size:24rpx;font-weight:600}'));
assert.ok(wxss.includes('.mode-tab.active{background:#fff;color:#2f875f'));
assert.ok(wxss.includes('.sync-card-error'));
assert.ok(fs.existsSync(path.join(__dirname, '../miniprogram/assets/sync-error.svg')));
assert.ok(fs.existsSync(path.join(__dirname, '../miniprogram/assets/sync-pending.svg')));
assert.ok(fs.existsSync(path.join(__dirname, '../miniprogram/assets/figma/s05-imgIconGeneratedIllustrated2.svg')));
assert.ok(fs.existsSync(path.join(__dirname, '../miniprogram/assets/figma/s05-imgIconGeneratedIllustrated3.svg')));
console.log('events page tests passed');
