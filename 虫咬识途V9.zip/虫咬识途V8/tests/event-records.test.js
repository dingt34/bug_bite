const assert = require('assert');
const records = require('../miniprogram/utils/event-records');

const createdAt = new Date(2026, 8, 1, 14, 30).getTime();
const event = records.createEvent({
  id: 'event_1', contactType: 'bite', riskLevel: 'observe', place: '公园草地',
  body: '右小腿', symptoms: ['红肿'], trend: '基本不变'
}, createdAt);
assert.strictEqual(event.timeline.length, 1);
assert.strictEqual(event.timeline[0].recordedAtTimestamp, createdAt);
assert.strictEqual(event.createdAt, '今天 14:30');

const reviewedAt = createdAt + 2 * 60 * 60 * 1000;
const reviewed = records.applyReview(event, {
  trend: '逐渐加重', range: '扩大', symptoms: ['红肿', '疼痛'], imageRefs: ['wxfile://review.jpg']
}, reviewedAt);
assert.strictEqual(reviewed.riskLevel, 'consult');
assert.strictEqual(reviewed.timeline.length, 2);
assert.strictEqual(reviewed.timeline[0].recordedAtTimestamp, createdAt);
assert.strictEqual(reviewed.timeline[1].recordedAtTimestamp, reviewedAt);
assert.strictEqual(reviewed.recoveryLogs.length, 1);
assert.deepStrictEqual(reviewed.timeline[0].symptoms, ['红肿']);
assert.deepStrictEqual(reviewed.symptoms, ['红肿', '疼痛']);
assert.strictEqual(records.matches(reviewed, '公园'), true);
assert.strictEqual(records.matches(reviewed, '蜂类'), false);
const cloudRecord = records.toCloudRecord(reviewed);
assert.strictEqual(cloudRecord.imageRefs, undefined);
assert.strictEqual(cloudRecord.timeline[1].imageRefs, undefined);
assert.deepStrictEqual(cloudRecord.imageFileIds, []);
assert.strictEqual(records.createEvent({ contactType: 'attached' }, createdAt).type, '发现附着虫体');
assert.strictEqual(records.createEvent({ contactType: 'attached' }, createdAt).contactType, 'attachment');
assert.strictEqual(records.createEvent({ contactType: 'bite' }, createdAt).place, '');
assert.strictEqual(records.normalizeEvent({ id: 'legacy_place', place: '待补充' }, createdAt).place, '');
assert.strictEqual(records.normalizeEvent({ id: 'legacy_bite', type: '蚊虫叮咬' }, createdAt).contactType, 'bite');
assert.strictEqual(records.normalizeEvent({ id: 'legacy_attachment', type: '发现附着虫体' }, createdAt).contactType, 'attachment');

const reopened = records.normalizeEvent(reviewed, reviewedAt + 30 * 60 * 1000);
assert.strictEqual(reopened.timeline[1].recordedAtTimestamp, reviewedAt);
assert.notStrictEqual(reopened.timeline[1].timeText, '刚刚');

const systemicReview = records.applyReview(event, {
  trend: '基本不变', range: '不变', symptoms: ['红肿'], systemicSymptoms: ['头晕']
}, reviewedAt);
assert.strictEqual(systemicReview.riskLevel, 'consult');
assert.strictEqual(systemicReview.highestRiskLevel, 'consult');
const recovered = records.applyReview(systemicReview, {
  trend: '明显减轻', range: '缩小', symptoms: [], systemicSymptoms: []
}, reviewedAt + 3600000);
assert.strictEqual(recovered.riskLevel, 'observe');
assert.strictEqual(recovered.highestRiskLevel, 'consult');
assert.strictEqual(recovered.status, '已恢复');
console.log('event record tests passed');
