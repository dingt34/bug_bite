const assert = require('assert');
const fs = require('fs');
const path = require('path');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'events'] = [
  { id: 'event_mosquito', type: '蚊虫叮咬', status: '待复查' },
  { id: 'event_bee', type: '蜂类蜇伤', status: '历史' },
  { id: 'event_real_1', type: '用户记录', status: '待复查' }
];
storage[prefix + 'plans'] = [];

let definition;
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  navigateTo() {}
};

require('../miniprogram/pages/profile/profile.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onShow();
assert.strictEqual(page.data.eventCount, 1);
assert.strictEqual(page.data.pendingEventCount, 1);
assert.strictEqual(page.data.eventSummary, '1 条记录 · 1 条待复查');
assert.strictEqual(page.data.event.id, 'event_real_1');
assert.strictEqual(page.data.planCount, 0);
assert.strictEqual(page.data.planSummary, '暂无计划');
assert.deepStrictEqual(storage[prefix + 'events'].map(item => item.id), ['event_real_1']);

const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/profile/profile.wxml'), 'utf8');
assert.ok(wxml.includes('{{eventSummary}}'));
assert.ok(!wxml.includes('3 条记录 · 1 条待复查'));
assert.ok(wxml.includes('{{planSummary}}'));
assert.ok(!wxml.includes('3 个计划 · 2 份离线卡'));

const homeJs = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/home/home.js'), 'utf8');
assert.ok(homeJs.includes('store.withoutDemoEvents'));
assert.ok(!homeJs.includes("|| 'event_mosquito'"));

console.log('profile page tests passed');
