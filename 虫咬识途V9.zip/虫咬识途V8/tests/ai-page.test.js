const assert = require('assert');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'plans'] = [
  { id: 'trip_lishui', title: '丽水古堰画乡', date: '8月18–20日', type: '徒步露营' },
  { id: 'trip_hangzhou', title: '杭州植物园步行', date: '9月6日', type: '步行' },
  { id: 'plan_1', title: '用户行程', date: '9月5日', type: '徒步' }
];
storage[prefix + 'events'] = [{
  id: 'event_1', type: '蚊虫叮咬', riskLevel: 'observe', place: '公园草地', body: '右小腿',
  symptoms: ['红肿'], trend: '基本不变', createdAtTimestamp: Date.now() - 3600000, status: '待复查',
  timeline: [
    { id: 'initial_1', kind: 'initial', title: '首次安全判断', recordedAtTimestamp: Date.now() - 3600000, riskLevel: 'observe', symptoms: ['红肿'], trend: '基本不变' },
    { id: 'review_1', kind: 'review', title: '第 1 次复查', recordedAtTimestamp: Date.now() - 1800000, riskLevel: 'observe', symptoms: ['红肿'], trend: '基本不变' }
  ]
}];

let definition;
let cloudPayload;
let modalTitle = '';
global.Page = value => { definition = value; };
global.getApp = () => ({ globalData: { cloudReady: true } });
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  showToast() {},
  showModal(options) { modalTitle = options.title; },
  navigateTo() {},
  cloud: {
    callFunction(options) {
      cloudPayload = options.data;
      return Promise.resolve({ result: { ok: true, data: { answer: '请继续观察记录。' } } });
    }
  }
};

require('../miniprogram/pages/ai/ai.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); },
  getTabBar() { return null; }
});

(async () => {
  assert.strictEqual(page.data.messages.length, 0);
  page.onShow();
  assert.deepStrictEqual(storage[prefix + 'plans'].map(item => item.id), ['plan_1']);
  assert.ok(!page.data.selectableRecords.some(item => item.key === 'plan:trip_lishui' || item.key === 'plan:trip_hangzhou'));
  assert.ok(page.data.suggestions[0].indexOf('用户行程') >= 0);
  page.toggleRecord({ currentTarget: { dataset: { key: 'event:event_1' } } });
  page.confirmRecords();
  page.setData({ input: '这条记录接下来注意什么？' });
  page.send();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.deepStrictEqual(cloudPayload.selectedRecordIds, ['event:event_1']);
  const lastContent = cloudPayload.messages[cloudPayload.messages.length - 1].content;
  assert.ok(lastContent.indexOf('蚊虫叮咬') >= 0);
  assert.ok(lastContent.indexOf('用户行程') < 0);
  assert.deepStrictEqual(page.data.selectedRecordIds, []);
  assert.strictEqual(page.data.selectedLabel, '未选择任何记录');
  assert.ok(page.data.selectableRecords.every(item => !item.selected));

  cloudPayload = null;
  page.setData({ input: '' });
  page.send();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.strictEqual(cloudPayload, null);

  page.toggleRecord({ currentTarget: { dataset: { key: 'event:event_1' } } });
  page.confirmRecords();
  page.send();
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.ok(cloudPayload);
  const recordOnlyContent = cloudPayload.messages[cloudPayload.messages.length - 1].content;
  assert.ok(recordOnlyContent.indexOf('请根据我选择的记录') >= 0);
  assert.ok(recordOnlyContent.indexOf('蚊虫叮咬') >= 0);
  const latestUser = page.data.messages.filter(item => item.role === 'user').pop();
  assert.ok(latestUser.attachmentLabel.indexOf('蚊虫叮咬') >= 0);
  assert.strictEqual(latestUser.attachments.length, 1);
  assert.strictEqual(latestUser.attachments[0].type, 'event');
  assert.strictEqual(latestUser.attachments[0].title, '蚊虫叮咬');
  assert.strictEqual(latestUser.attachments[0].icon, '/assets/figma/all/s13-img3.svg');
  assert.ok(latestUser.attachments[0].detail.indexOf('右小腿') >= 0);
  assert.ok(latestUser.attachments[0].detail.indexOf('红肿') >= 0);
  assert.strictEqual(latestUser.attachments[0].reviewStatus, '已复查 1 次 · 仍待复查');
  assert.strictEqual(latestUser.attachments[0].reviewState, 'reviewed');
  assert.strictEqual(latestUser.attachments[0].timeline.length, 2);
  assert.strictEqual(latestUser.attachments[0].timeline[1].title, '第 1 次复查');
  assert.ok(page.data.scrollIntoView.indexOf('chat-bottom-') === 0);
  assert.deepStrictEqual(page.data.selectedRecordIds, []);

  page.clearRecords();
  page.saveLastAnswer();
  assert.strictEqual(storage[prefix + 'events'][0].notes.length, 1);
  assert.deepStrictEqual(storage[prefix + 'events'][0].notes[0].selectedRecordIds, ['event:event_1']);

  const eventOption = page.data.selectableRecords.find(item => item.key === 'event:event_1');
  eventOption.summary += '，并出现呼吸困难';
  page.toggleRecord({ currentTarget: { dataset: { key: 'event:event_1' } } });
  page.confirmRecords();
  cloudPayload = null;
  page.setData({ input: '' });
  page.send();
  assert.strictEqual(modalTitle, '先进行安全判断');
  assert.strictEqual(cloudPayload, null);

  page.clearRecords();
  cloudPayload = null;
  page.setData({ input: '现在呼吸困难而且快速加重' });
  page.send();
  assert.strictEqual(modalTitle, '先进行安全判断');
  assert.strictEqual(cloudPayload, null);
  const wxml = require('fs').readFileSync(require('path').join(__dirname, '../miniprogram/pages/ai/ai.wxml'), 'utf8');
  const wxss = require('fs').readFileSync(require('path').join(__dirname, '../miniprogram/pages/ai/ai.wxss'), 'utf8');
  assert.ok(wxml.includes('class="ai-controls"'));
  assert.ok(wxml.includes('class="danger-alert-mark">!</text>'));
  assert.ok(wxml.includes('chat-bottom-{{scrollToken}}'));
  assert.ok(wxml.includes('class="message-record-card"'));
  assert.ok(wxml.includes('{{record.subtitle}}'));
  assert.ok(wxml.includes('class="message-record-image"'));
  assert.ok(wxml.includes('class="message-record-detail"'));
  assert.ok(wxml.includes("item.attachments.length?'has-records':''"));
  assert.ok(wxml.includes('class="message-review-badge {{record.reviewState}}"'));
  assert.ok(wxml.includes('class="message-timeline-item"'));
  assert.ok(wxml.includes("wx:if=\"{{item.role==='user'}}\" class=\"user-avatar\">我</view>"));
  assert.ok(!wxml.includes("record.type==='plan'?'行':'事'"));
  assert.ok(wxss.includes('.record-picker{position:relative'));
  assert.ok(wxss.includes('.page.with-tab.ai-page'));
  assert.ok(wxss.includes('.danger-alert-mark{position:relative;z-index:1;color:#df4138'));
  assert.ok(wxss.includes('.message-record-card{width:100%;min-height:76rpx'));
  assert.ok(wxss.includes('.message-record-icon{width:50rpx;height:50rpx'));
  assert.ok(wxss.includes('.bubble-text.has-records{width:94%;max-width:94%'));
  assert.ok(wxss.includes('.message-record-card{min-height:102rpx'));
  assert.ok(wxss.includes('-webkit-line-clamp:2'));
  assert.ok(wxss.includes('.message-review-row{margin-top:10rpx'));
  assert.ok(wxss.includes('.message-timeline{margin-top:12rpx'));
  assert.ok(wxss.includes('.user-avatar{width:64rpx;height:64rpx'));
  assert.ok(wxss.includes('.bubble.user .bubble-text.has-records{width:calc(100% - 78rpx)'));
  assert.ok(wxss.includes('.message-record-title{overflow:hidden;text-overflow:ellipsis'));
  const cloudCode = require('fs').readFileSync(require('path').join(__dirname, '../cloudfunctions/aiAssistant/index.js'), 'utf8');
  assert.ok(cloudCode.includes("console.error('ai audit skipped'"));
  console.log('ai page tests passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
