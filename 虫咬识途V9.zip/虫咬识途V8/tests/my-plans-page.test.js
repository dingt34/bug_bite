const assert = require('assert');
const fs = require('fs');
const path = require('path');

const prefix = 'bugtrail_v4_';
const storage = {};
storage[prefix + 'plans'] = [
  { id: 'trip_lishui', title: '丽水古堰画乡' },
  { id: 'trip_hangzhou', title: '杭州植物园步行' },
  { id: 'trip_real_1', title: '用户行程', date: '10月2日', type: '骑行', status: '新计划' }
];

let definition;
global.Page = value => { definition = value; };
global.wx = {
  getStorageSync(key) { return storage[key] === undefined ? '' : storage[key]; },
  setStorageSync(key, value) { storage[key] = value; },
  removeStorageSync(key) { delete storage[key]; },
  navigateTo() {}
};

require('../miniprogram/pages/my-plans/my-plans.js');
const page = Object.assign({}, definition, {
  data: JSON.parse(JSON.stringify(definition.data)),
  setData(update) { this.data = Object.assign({}, this.data, update); }
});

page.onShow();
assert.deepStrictEqual(page.data.plans.map(item => item.id), ['trip_real_1']);
assert.strictEqual(page.data.mainPlan.title, '用户行程');
assert.deepStrictEqual(storage[prefix + 'plans'].map(item => item.id), ['trip_real_1']);

const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/my-plans/my-plans.wxml'), 'utf8');
const wxss = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/my-plans/my-plans.wxss'), 'utf8');
assert.ok(wxml.includes('{{mainPlan.title}}'));
assert.ok(wxml.includes('暂无行程计划'));
assert.ok(!wxml.includes('>丽水古堰画乡<'));
assert.ok(wxss.includes('.empty-card{margin-top:36rpx'));

console.log('my plans page tests passed');
